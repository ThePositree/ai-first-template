import { SiteNav } from '@/components/site-nav'
import { Hero } from '@/components/hero'
import { MemoryMap } from '@/components/memory-map'
import { Workflow } from '@/components/workflow'
import { TaskMemory } from '@/components/task-memory'
import { OwnerControl } from '@/components/owner-control'
import { Principles } from '@/components/principles'
import { InstallCta } from '@/components/install-cta'
import { SiteFooter } from '@/components/site-footer'

export default function Page() {
  return (
    <div className="min-h-screen bg-background">
      <SiteNav />
      <main>
        <Hero />
        <MemoryMap />
        <Workflow />
        <TaskMemory />
        <OwnerControl />
        <Principles />
        <InstallCta />
      </main>
      <SiteFooter />
    </div>
  )
}
