import {
  ChatText,
  DownloadSimple,
  ArrowsClockwise,
} from '@phosphor-icons/react/dist/ssr'

const STEPS = [
  {
    icon: DownloadSimple,
    title: 'Install once',
    body: 'Run one command in your repo. AI-first writes the .ai-first workspace and an AGENTS.md handoff. No global CLI, no persistent binary.',
    line: 'curl -fsSL https://ai-first.dev/install | sh',
  },
  {
    icon: ChatText,
    title: 'Keep talking normally',
    body: 'Nothing about how you work changes. You prompt your agent the same way. It reads local memory and writes back as work progresses.',
    line: '"Add rate limiting to the API"',
  },
  {
    icon: ArrowsClockwise,
    title: 'Fresh chats recover context',
    body: 'Start a brand-new chat and the agent reloads project state instantly — current work, backlog, decisions — with zero re-explaining.',
    line: '"Continue where we left off"',
  },
]

export function Workflow() {
  return (
    <section
      id="workflow"
      className="relative scroll-mt-20 border-y border-border/60 bg-muted/20"
    >
      <div className="mx-auto w-full max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
        <div className="max-w-2xl">
          <span className="font-mono text-xs uppercase tracking-wider text-primary">
            The workflow
          </span>
          <h2 className="mt-3 text-pretty text-3xl font-semibold tracking-tight sm:text-4xl">
            Set it up once. Then just keep building.
          </h2>
          <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
            AI-first is deliberately boring to operate. It does not replace your
            agent or ask you to learn a new tool — it quietly keeps the context
            your agent needs.
          </p>
        </div>

        <ol className="mt-10 grid gap-4 md:grid-cols-3">
          {STEPS.map((step, i) => {
            const Icon = step.icon
            return (
              <li
                key={step.title}
                className="relative flex flex-col rounded-xl border border-border bg-card p-5"
              >
                <div className="flex items-center gap-3">
                  <span className="flex size-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
                    <Icon weight="bold" className="size-4.5" />
                  </span>
                  <span className="font-mono text-sm font-semibold text-muted-foreground">
                    Step {i + 1}
                  </span>
                </div>

                <h3 className="mt-4 text-lg font-semibold tracking-tight">
                  {step.title}
                </h3>
                <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">
                  {step.body}
                </p>

                <div className="mt-4 flex items-center gap-2 rounded-lg border border-border/70 bg-background px-3 py-2">
                  <span className="font-mono text-xs font-semibold text-primary">
                    {i === 0 ? '$' : '›'}
                  </span>
                  <code className="truncate font-mono text-[0.72rem] text-muted-foreground">
                    {step.line}
                  </code>
                </div>
              </li>
            )
          })}
        </ol>
      </div>
    </section>
  )
}
