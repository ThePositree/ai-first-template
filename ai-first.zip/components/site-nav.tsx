'use client'

import { GithubLogo, Stack } from '@phosphor-icons/react'
import { Button } from '@/components/ui/button'
import { ThemeToggle } from '@/components/theme-toggle'

const NAV_LINKS = [
  { label: 'Memory', href: '#memory' },
  { label: 'Workflow', href: '#workflow' },
  { label: 'Tasks', href: '#tasks' },
  { label: 'Control', href: '#control' },
]

export function SiteNav() {
  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-background/80 backdrop-blur-md">
      <div className="mx-auto flex h-14 w-full max-w-6xl items-center justify-between gap-4 px-4 sm:px-6">
        <a href="#top" className="flex items-center gap-2.5">
          <span className="flex size-7 items-center justify-center rounded-md bg-primary text-primary-foreground">
            <Stack weight="fill" className="size-4" />
          </span>
          <span className="text-sm font-semibold tracking-tight">
            AI-first
          </span>
          <span className="hidden rounded-full border border-border px-1.5 py-0.5 font-mono text-[0.6rem] text-muted-foreground sm:inline">
            v0.4
          </span>
        </a>

        <nav className="hidden items-center gap-1 md:flex">
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="rounded-md px-2.5 py-1.5 text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <ThemeToggle />
          <Button
            variant="outline"
            size="sm"
            nativeButton={false}
            render={
              <a
                href="https://github.com"
                target="_blank"
                rel="noreferrer noopener"
              />
            }
          >
            <GithubLogo weight="bold" className="size-3.5" />
            <span className="hidden sm:inline">Star</span>
            <span className="font-mono text-xs text-muted-foreground">4.2k</span>
          </Button>
          <Button size="sm" nativeButton={false} render={<a href="#install" />}>
            Install
          </Button>
        </div>
      </div>
    </header>
  )
}
