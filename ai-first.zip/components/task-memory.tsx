import { ArrowRight, Kanban } from '@phosphor-icons/react/dist/ssr'

const TASKS = [
  { id: 'AF-128', title: 'Rate limit the public API', state: 'In progress', file: 'IN_PROGRESS.md' },
  { id: 'AF-131', title: 'Migrate auth to sessions', state: 'Backlog', file: 'BACKLOG.md' },
  { id: 'AF-140', title: 'Explore local vector recall', state: 'Idea', file: 'IDEAS.md' },
]

const TRACKERS = ['Jira', 'Linear', 'Confluence', 'Notion']

export function TaskMemory() {
  return (
    <section id="tasks" className="mx-auto w-full max-w-6xl scroll-mt-20 px-4 py-16 sm:px-6 lg:py-24">
      <div className="grid gap-10 lg:grid-cols-2 lg:items-center lg:gap-16">
        <div>
          <span className="font-mono text-xs uppercase tracking-wider text-primary">
            Task memory
          </span>
          <h2 className="mt-3 text-pretty text-3xl font-semibold tracking-tight sm:text-4xl">
            Work items live in your repo — and can travel later.
          </h2>
          <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
            In-progress work, backlog, and ideas are tracked as memory next to
            your code. It stays local and file-based by default. When you&apos;re
            ready, task memory can sync or export into the trackers your team
            already uses.
          </p>

          <div className="mt-6">
            <div className="mb-2 font-mono text-[0.7rem] uppercase tracking-wider text-muted-foreground">
              On the roadmap — export targets
            </div>
            <div className="flex flex-wrap gap-2">
              {TRACKERS.map((t) => (
                <span
                  key={t}
                  className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1 text-xs text-muted-foreground"
                >
                  <span className="size-1.5 rounded-full bg-primary/60" />
                  {t}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* board mock */}
        <div className="rounded-2xl border border-border bg-card/70 p-4 shadow-sm sm:p-5">
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm font-medium">
              <Kanban weight="fill" className="size-4 text-primary" />
              Task memory
            </div>
            <span className="font-mono text-[0.65rem] text-muted-foreground">
              local · file-backed
            </span>
          </div>

          <ul className="space-y-2.5">
            {TASKS.map((task) => (
              <li
                key={task.id}
                className="flex items-center gap-3 rounded-lg border border-border/70 bg-background p-3"
              >
                <span className="font-mono text-[0.7rem] font-semibold text-primary">
                  {task.id}
                </span>
                <span className="flex-1 truncate text-sm text-foreground">
                  {task.title}
                </span>
                <span className="hidden rounded-full border border-border bg-muted px-2 py-0.5 font-mono text-[0.6rem] text-muted-foreground sm:inline">
                  {task.state}
                </span>
                <code className="font-mono text-[0.65rem] text-muted-foreground/70">
                  {task.file}
                </code>
              </li>
            ))}
          </ul>

          <div className="mt-4 flex items-center justify-between rounded-lg border border-dashed border-primary/30 bg-primary/5 px-3 py-2.5">
            <span className="text-xs text-muted-foreground">
              Sync to Jira · Linear · Confluence
            </span>
            <span className="inline-flex items-center gap-1 font-mono text-[0.65rem] text-primary">
              coming soon
              <ArrowRight weight="bold" className="size-3" />
            </span>
          </div>
        </div>
      </div>
    </section>
  )
}
