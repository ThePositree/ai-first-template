import { FileText, FolderSimple } from '@phosphor-icons/react/dist/ssr'
import { MEMORY_FILES, type MemoryFile } from '@/components/site-data'
import { cn } from '@/lib/utils'

const STATUS_STYLES: Record<MemoryFile['status'], string> = {
  live: 'border-primary/30 bg-primary/10 text-primary',
  active: 'border-primary/40 bg-primary/15 text-primary',
  queued: 'border-border bg-muted text-muted-foreground',
  draft: 'border-border bg-muted text-muted-foreground',
}

export function MemoryMap() {
  return (
    <section id="memory" className="mx-auto w-full max-w-6xl scroll-mt-20 px-4 py-16 sm:px-6 lg:py-24">
      <div className="max-w-2xl">
        <span className="font-mono text-xs uppercase tracking-wider text-primary">
          The memory map
        </span>
        <h2 className="mt-3 text-pretty text-3xl font-semibold tracking-tight sm:text-4xl">
          Eight files. The whole story of your project.
        </h2>
        <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
          Everything lives as plain Markdown in your repo. Open it, diff it,
          edit it, commit it. The files are the interface — no database, no
          dashboard, no lock-in.
        </p>
      </div>

      {/* path breadcrumb */}
      <div className="mt-8 flex items-center gap-2 rounded-lg border border-border bg-card/60 px-3 py-2 font-mono text-xs text-muted-foreground">
        <FolderSimple weight="fill" className="size-3.5 text-primary" />
        <span className="text-foreground">.ai-first</span>
        <span>/</span>
        <span className="text-foreground">context</span>
        <span>/</span>
        <span className="text-muted-foreground/60">8 files</span>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {MEMORY_FILES.map((file, i) => (
          <article
            key={file.name}
            className="group relative flex flex-col rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary/40"
          >
            <div className="flex items-start justify-between gap-2">
              <span className="flex size-8 items-center justify-center rounded-md border border-border bg-muted/50 text-primary transition-colors group-hover:bg-primary/10">
                <FileText weight="regular" className="size-4" />
              </span>
              <span
                className={cn(
                  'inline-flex items-center gap-1 rounded-full border px-1.5 py-0.5 font-mono text-[0.6rem] uppercase tracking-wide',
                  STATUS_STYLES[file.status],
                )}
              >
                {file.status}
              </span>
            </div>

            <h3 className="mt-3 font-mono text-sm font-semibold text-foreground">
              {file.name}
            </h3>
            <p className="mt-1.5 flex-1 text-[0.8rem] leading-relaxed text-muted-foreground">
              {file.description}
            </p>

            <div className="mt-3 flex items-center justify-between border-t border-border/60 pt-2.5 font-mono text-[0.65rem] text-muted-foreground">
              <span>{file.label}</span>
              <span className="tabular-nums">{file.lines} lines</span>
            </div>

            <span
              aria-hidden
              className="absolute right-3 top-3 font-mono text-[0.6rem] text-muted-foreground/40"
            >
              {String(i + 1).padStart(2, '0')}
            </span>
          </article>
        ))}
      </div>

      {/* AGENTS.md callout */}
      <div className="mt-4 flex flex-col gap-3 rounded-xl border border-border bg-gradient-to-br from-card to-muted/30 p-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-3">
          <span className="flex size-9 items-center justify-center rounded-md bg-primary text-primary-foreground">
            <FileText weight="bold" className="size-4" />
          </span>
          <div>
            <h3 className="font-mono text-sm font-semibold">AGENTS.md</h3>
            <p className="mt-0.5 max-w-md text-[0.8rem] leading-relaxed text-muted-foreground">
              A root handoff file that tells any agent where memory lives and
              how to read it — the first thing a fresh chat picks up.
            </p>
          </div>
        </div>
        <code className="shrink-0 self-start rounded-md border border-border bg-background px-2.5 py-1.5 font-mono text-xs text-muted-foreground sm:self-auto">
          ./AGENTS.md
        </code>
      </div>
    </section>
  )
}
