'use client'

import * as React from 'react'
import { Check, Copy, Terminal } from '@phosphor-icons/react'
import { INSTALL_COMMAND } from '@/components/site-data'
import { cn } from '@/lib/utils'

export function InstallCard({ className }: { className?: string }) {
  const [copied, setCopied] = React.useState(false)

  const copy = React.useCallback(async () => {
    try {
      await navigator.clipboard.writeText(INSTALL_COMMAND)
      setCopied(true)
      setTimeout(() => setCopied(false), 1600)
    } catch {
      /* clipboard unavailable */
    }
  }, [])

  return (
    <div
      className={cn(
        'group relative overflow-hidden rounded-xl border border-border bg-card shadow-sm',
        className,
      )}
    >
      {/* window chrome */}
      <div className="flex items-center gap-2 border-b border-border/70 bg-muted/40 px-4 py-2.5">
        <div className="flex items-center gap-1.5">
          <span className="size-2.5 rounded-full bg-border" />
          <span className="size-2.5 rounded-full bg-border" />
          <span className="size-2.5 rounded-full bg-border" />
        </div>
        <div className="ml-1 flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
          <Terminal weight="bold" className="size-3.5" />
          <span className="font-mono">install</span>
        </div>
      </div>

      <div className="flex items-center gap-3 px-4 py-4 sm:px-5">
        <span
          aria-hidden
          className="font-mono text-sm font-semibold text-primary"
        >
          $
        </span>
        <code className="flex-1 truncate font-mono text-[0.82rem] text-foreground sm:text-sm">
          {INSTALL_COMMAND}
        </code>
        <button
          type="button"
          onClick={copy}
          aria-label="Copy install command"
          className="inline-flex size-8 shrink-0 items-center justify-center rounded-md border border-border bg-background text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 focus-visible:outline-none"
        >
          {copied ? (
            <Check weight="bold" className="size-4 text-primary" />
          ) : (
            <Copy weight="bold" className="size-4" />
          )}
        </button>
      </div>

      <div className="flex items-center justify-between border-t border-border/70 px-4 py-2.5 text-[0.7rem] text-muted-foreground sm:px-5">
        <span className="font-mono">
          {copied ? 'copied to clipboard' : 'no npx · no global binary · no node_modules'}
        </span>
        <span className="font-mono tabular-nums">~2s</span>
      </div>
    </div>
  )
}
