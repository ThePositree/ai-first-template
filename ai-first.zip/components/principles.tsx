import {
  FileCode,
  HardDrives,
  MagnifyingGlass,
  Prohibit,
} from '@phosphor-icons/react/dist/ssr'

const PRINCIPLES = [
  {
    icon: HardDrives,
    title: 'Local-first',
    body: 'Memory lives in your repo, on your machine. Nothing is shipped to a server you don\u2019t control.',
  },
  {
    icon: MagnifyingGlass,
    title: 'Inspectable',
    body: 'Plain Markdown you can open, diff, and edit. If you can read a file, you can audit the memory.',
  },
  {
    icon: FileCode,
    title: 'Files are the interface',
    body: 'No dashboard to learn. The workspace is the product — versioned right alongside your code.',
  },
  {
    icon: Prohibit,
    title: 'Zero footprint',
    body: 'No global CLI, no npx, no persistent binary, no node_modules inside your target repo.',
  },
]

export function Principles() {
  return (
    <section className="mx-auto w-full max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
      <div className="max-w-2xl">
        <span className="font-mono text-xs uppercase tracking-wider text-primary">
          Principles
        </span>
        <h2 className="mt-3 text-pretty text-3xl font-semibold tracking-tight sm:text-4xl">
          Quiet power, nothing hidden.
        </h2>
      </div>

      <div className="mt-10 grid gap-px overflow-hidden rounded-2xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-4">
        {PRINCIPLES.map((p) => {
          const Icon = p.icon
          return (
            <div
              key={p.title}
              className="flex flex-col bg-card p-6 transition-colors hover:bg-muted/30"
            >
              <span className="flex size-10 items-center justify-center rounded-lg border border-border bg-background text-primary">
                <Icon weight="bold" className="size-5" />
              </span>
              <h3 className="mt-4 text-base font-semibold tracking-tight">
                {p.title}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {p.body}
              </p>
            </div>
          )
        })}
      </div>
    </section>
  )
}
