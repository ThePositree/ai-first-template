import { BookOpen, GithubLogo } from '@phosphor-icons/react/dist/ssr'
import { Button } from '@/components/ui/button'
import { InstallCard } from '@/components/install-card'

export function InstallCta() {
  return (
    <section
      id="install"
      className="relative scroll-mt-20 overflow-hidden border-t border-border/60"
    >
      <div
        aria-hidden
        className="bg-dot-grid pointer-events-none absolute inset-0 opacity-50 [mask-image:radial-gradient(ellipse_60%_60%_at_50%_100%,black,transparent)]"
      />
      <div className="relative mx-auto flex w-full max-w-3xl flex-col items-center px-4 py-20 text-center sm:px-6 lg:py-28">
        <h2 className="text-balance text-3xl font-semibold tracking-tight sm:text-4xl lg:text-5xl">
          Give your repo a memory.
        </h2>
        <p className="mt-4 max-w-xl text-pretty leading-relaxed text-muted-foreground">
          One command. Local, inspectable, file-based memory that your agent
          reads on every fresh chat. Keep talking to your agent the way you
          already do.
        </p>

        <div className="mt-8 w-full max-w-md">
          <InstallCard />
        </div>

        <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
          <Button
            size="lg"
            nativeButton={false}
            render={
              <a href="https://github.com" target="_blank" rel="noreferrer noopener" />
            }
          >
            <GithubLogo weight="bold" className="size-4" />
            View on GitHub
          </Button>
          <Button variant="outline" size="lg" nativeButton={false} render={<a href="#memory" />}>
            <BookOpen weight="bold" className="size-4" />
            Read the docs
          </Button>
        </div>
      </div>
    </section>
  )
}
