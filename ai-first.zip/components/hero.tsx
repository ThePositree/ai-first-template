import { ArrowRight, FolderSimple, Sparkle } from '@phosphor-icons/react/dist/ssr'
import { Button } from '@/components/ui/button'
import { InstallCard } from '@/components/install-card'
import { AgentHandoff } from '@/components/agent-handoff'

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden">
      {/* dotted grid backdrop, fading toward edges */}
      <div
        aria-hidden
        className="bg-dot-grid pointer-events-none absolute inset-0 opacity-60 [mask-image:radial-gradient(ellipse_70%_60%_at_50%_0%,black,transparent)]"
      />

      <div className="relative mx-auto grid w-full max-w-6xl gap-12 px-4 pt-16 pb-8 sm:px-6 lg:grid-cols-[1.05fr_0.95fr] lg:gap-10 lg:pt-24 lg:pb-14">
        {/* left column */}
        <div className="flex flex-col items-start">
          <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-3 py-1 text-xs text-muted-foreground backdrop-blur">
            <Sparkle weight="fill" className="size-3.5 text-primary" />
            Local memory layer for AI-assisted repos
          </div>

          <h1 className="mt-6 text-pretty text-4xl font-semibold leading-[1.05] tracking-tight sm:text-5xl lg:text-6xl">
            Your agent forgets.
            <br />
            <span className="text-primary">Your repo remembers.</span>
          </h1>

          <p className="mt-5 max-w-xl text-pretty text-base leading-relaxed text-muted-foreground sm:text-lg">
            AI-first drops a lightweight{' '}
            <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-[0.85em] text-foreground">
              .ai-first
            </code>{' '}
            workspace and a root{' '}
            <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-[0.85em] text-foreground">
              AGENTS.md
            </code>{' '}
            handoff into your project. Fresh chats recover the full picture —
            current work, backlog, decisions, architecture — so you stop
            re-explaining and keep building.
          </p>

          <div className="mt-8 flex w-full max-w-md flex-col gap-3">
            <InstallCard />
            <div className="flex flex-wrap items-center gap-3">
              <Button size="lg" nativeButton={false} render={<a href="#workflow" />}>
                See how it works
                <ArrowRight weight="bold" className="size-4" />
              </Button>
              <Button variant="ghost" size="lg" nativeButton={false} render={<a href="#memory" />}>
                <FolderSimple weight="bold" className="size-4" />
                Explore the memory map
              </Button>
            </div>
          </div>

          <dl className="mt-10 grid grid-cols-3 gap-6 border-t border-border/60 pt-6">
            {[
              { k: 'One', v: 'command install' },
              { k: '0', v: 'binaries in your repo' },
              { k: '100%', v: 'local & inspectable' },
            ].map((stat) => (
              <div key={stat.v}>
                <dt className="font-mono text-xl font-semibold tracking-tight sm:text-2xl">
                  {stat.k}
                </dt>
                <dd className="mt-0.5 text-xs leading-snug text-muted-foreground">
                  {stat.v}
                </dd>
              </div>
            ))}
          </dl>
        </div>

        {/* right column — the handoff visual */}
        <div className="relative lg:pl-2">
          <AgentHandoff />
        </div>
      </div>
    </section>
  )
}
