import { GithubLogo, Stack } from '@phosphor-icons/react/dist/ssr'

const COLUMNS = [
  {
    title: 'Product',
    links: ['Memory map', 'Workflow', 'Task memory', 'Owner control'],
  },
  {
    title: 'Docs',
    links: ['Install', 'AGENTS.md spec', 'File reference', 'FAQ'],
  },
  {
    title: 'Project',
    links: ['GitHub', 'Changelog', 'Roadmap', 'License (MIT)'],
  },
]

export function SiteFooter() {
  return (
    <footer className="border-t border-border/60 bg-background">
      <div className="mx-auto w-full max-w-6xl px-4 py-12 sm:px-6">
        <div className="grid gap-10 md:grid-cols-[1.5fr_1fr_1fr_1fr]">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="flex size-7 items-center justify-center rounded-md bg-primary text-primary-foreground">
                <Stack weight="fill" className="size-4" />
              </span>
              <span className="text-sm font-semibold tracking-tight">
                AI-first
              </span>
            </div>
            <p className="mt-3 max-w-xs text-[0.8rem] leading-relaxed text-muted-foreground">
              A local memory layer for AI-assisted repositories. Install once,
              keep building.
            </p>
            <code className="mt-4 inline-block rounded-md border border-border bg-muted/50 px-2.5 py-1.5 font-mono text-[0.7rem] text-muted-foreground">
              curl -fsSL ai-first.dev/install | sh
            </code>
          </div>

          {COLUMNS.map((col) => (
            <div key={col.title}>
              <h3 className="font-mono text-[0.7rem] uppercase tracking-wider text-muted-foreground">
                {col.title}
              </h3>
              <ul className="mt-3 space-y-2">
                {col.links.map((link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-10 flex flex-col items-start justify-between gap-3 border-t border-border/60 pt-6 sm:flex-row sm:items-center">
          <p className="font-mono text-[0.7rem] text-muted-foreground">
            © {new Date().getFullYear()} AI-first · Open source, MIT licensed
          </p>
          <a
            href="https://github.com"
            target="_blank"
            rel="noreferrer noopener"
            className="inline-flex items-center gap-1.5 text-[0.75rem] text-muted-foreground transition-colors hover:text-foreground"
          >
            <GithubLogo weight="bold" className="size-3.5" />
            Contribute on GitHub
          </a>
        </div>
      </div>
    </footer>
  )
}
