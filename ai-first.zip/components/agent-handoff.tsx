import {
  ChatCircleDots,
  CheckCircle,
  FileText,
  Robot,
} from '@phosphor-icons/react/dist/ssr'

const READS = [
  { file: 'PROJECT.md', tag: 'stack + entry points' },
  { file: 'IN_PROGRESS.md', tag: 'current task' },
  { file: 'ARCHITECTURE.md', tag: 'system shape' },
  { file: 'CHANGELOG.md', tag: 'past decisions' },
]

export function AgentHandoff() {
  return (
    <div className="relative rounded-2xl border border-border bg-card/70 p-4 shadow-sm backdrop-blur sm:p-5">
      {/* header */}
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm font-medium">
          <span className="flex size-6 items-center justify-center rounded-md bg-primary/10 text-primary">
            <Robot weight="fill" className="size-3.5" />
          </span>
          Fresh chat
        </div>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-background px-2 py-0.5 font-mono text-[0.65rem] text-muted-foreground">
          <span className="size-1.5 rounded-full bg-primary" />
          recovering context
        </span>
      </div>

      {/* prompt bubble */}
      <div className="flex items-start gap-2.5 rounded-lg border border-border/70 bg-muted/40 p-3">
        <ChatCircleDots weight="fill" className="mt-0.5 size-4 text-muted-foreground" />
        <p className="text-sm leading-relaxed text-foreground">
          &ldquo;Continue where we left off.&rdquo;
        </p>
      </div>

      {/* thread connector */}
      <div className="relative my-1 flex justify-center py-1">
        <svg
          width="2"
          height="24"
          viewBox="0 0 2 24"
          className="text-primary/50"
          aria-hidden
        >
          <line
            x1="1"
            y1="0"
            x2="1"
            y2="24"
            stroke="currentColor"
            strokeWidth="2"
            className="animate-thread"
          />
        </svg>
      </div>

      {/* reads list */}
      <div className="rounded-lg border border-border/70 bg-background/60 p-2">
        <div className="mb-1.5 px-1.5 font-mono text-[0.65rem] uppercase tracking-wider text-muted-foreground">
          reading .ai-first/context/
        </div>
        <ul className="space-y-0.5">
          {READS.map((r) => (
            <li
              key={r.file}
              className="flex items-center gap-2 rounded-md px-1.5 py-1.5 text-sm transition-colors hover:bg-muted/60"
            >
              <FileText weight="regular" className="size-4 text-primary" />
              <span className="font-mono text-[0.8rem] text-foreground">
                {r.file}
              </span>
              <span className="ml-auto truncate text-[0.7rem] text-muted-foreground">
                {r.tag}
              </span>
            </li>
          ))}
        </ul>
      </div>

      {/* result */}
      <div className="mt-3 flex items-center gap-2.5 rounded-lg border border-primary/25 bg-primary/5 p-3">
        <CheckCircle weight="fill" className="size-5 text-primary" />
        <div>
          <p className="text-sm font-medium text-foreground">
            Context recovered
          </p>
          <p className="text-[0.72rem] leading-snug text-muted-foreground">
            Agent resumes with backlog, decisions, and architecture in hand.
          </p>
        </div>
      </div>
    </div>
  )
}
