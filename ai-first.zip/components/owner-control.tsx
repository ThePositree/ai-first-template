import { Check, Lightbulb, ShieldCheck, X } from '@phosphor-icons/react/dist/ssr'

const PROPOSALS = [
  { text: 'Add a caching layer in front of the DB', approved: true },
  { text: 'Swap the ORM for raw SQL', approved: false },
  { text: 'Document the deploy runbook', approved: true },
]

export function OwnerControl() {
  return (
    <section
      id="control"
      className="relative scroll-mt-20 border-y border-border/60 bg-muted/20"
    >
      <div className="mx-auto w-full max-w-6xl px-4 py-16 sm:px-6 lg:py-24">
        <div className="grid gap-10 lg:grid-cols-2 lg:items-center lg:gap-16">
          {/* proposal review mock */}
          <div className="order-2 rounded-2xl border border-border bg-card/70 p-4 shadow-sm sm:p-5 lg:order-1">
            <div className="mb-4 flex items-center gap-2 text-sm font-medium">
              <Lightbulb weight="fill" className="size-4 text-primary" />
              Agent proposals
              <span className="ml-auto font-mono text-[0.65rem] text-muted-foreground">
                awaiting review
              </span>
            </div>

            <ul className="space-y-2.5">
              {PROPOSALS.map((p) => (
                <li
                  key={p.text}
                  className="flex items-center gap-3 rounded-lg border border-border/70 bg-background p-3"
                >
                  <span className="flex-1 text-sm text-foreground">
                    {p.text}
                  </span>
                  {p.approved ? (
                    <span className="inline-flex items-center gap-1 rounded-full border border-primary/30 bg-primary/10 px-2 py-0.5 font-mono text-[0.6rem] text-primary">
                      <Check weight="bold" className="size-3" />
                      saved
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 rounded-full border border-border bg-muted px-2 py-0.5 font-mono text-[0.6rem] text-muted-foreground">
                      <X weight="bold" className="size-3" />
                      dismissed
                    </span>
                  )}
                </li>
              ))}
            </ul>

            <p className="mt-4 rounded-lg bg-muted/50 px-3 py-2 text-[0.72rem] leading-relaxed text-muted-foreground">
              Ideas land in{' '}
              <code className="font-mono text-foreground">IDEAS.md</code> as
              proposals. Nothing enters durable memory until you say yes.
            </p>
          </div>

          {/* copy */}
          <div className="order-1 lg:order-2">
            <span className="font-mono text-xs uppercase tracking-wider text-primary">
              Owner control
            </span>
            <h2 className="mt-3 text-pretty text-3xl font-semibold tracking-tight sm:text-4xl">
              The agent can suggest. You decide what sticks.
            </h2>
            <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
              AI-first is transparent by design. Agents can propose ideas,
              decisions, and next steps — but the owner approves what gets
              written to memory. No silent edits, no surprise state.
            </p>

            <ul className="mt-6 space-y-3">
              {[
                { icon: ShieldCheck, t: 'Approve-to-save', d: 'Proposals stay in IDEAS.md until you promote them.' },
                { icon: Check, t: 'Human-readable diffs', d: 'Every change is plain Markdown you can review in git.' },
                { icon: Lightbulb, t: 'No hidden state', d: 'What the agent knows is exactly what is on disk.' },
              ].map((item) => {
                const Icon = item.icon
                return (
                  <li key={item.t} className="flex items-start gap-3">
                    <span className="mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-md bg-primary/10 text-primary">
                      <Icon weight="bold" className="size-4" />
                    </span>
                    <div>
                      <p className="text-sm font-medium text-foreground">
                        {item.t}
                      </p>
                      <p className="text-[0.8rem] leading-relaxed text-muted-foreground">
                        {item.d}
                      </p>
                    </div>
                  </li>
                )
              })}
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}
