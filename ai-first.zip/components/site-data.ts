export const INSTALL_COMMAND = 'curl -fsSL https://ai-first.dev/install | sh'

export type MemoryFile = {
  name: string
  path: string
  label: string
  description: string
  status: 'live' | 'active' | 'queued' | 'draft'
  lines: number
}

export const MEMORY_FILES: MemoryFile[] = [
  {
    name: 'PROJECT.md',
    path: '.ai-first/context/PROJECT.md',
    label: 'Overview',
    description: 'What the repo is, stack, entry points, and how to run it.',
    status: 'live',
    lines: 84,
  },
  {
    name: 'VISION.md',
    path: '.ai-first/context/VISION.md',
    label: 'Direction',
    description: 'Long-term product intent and the problems worth solving.',
    status: 'live',
    lines: 41,
  },
  {
    name: 'REQUIREMENTS.md',
    path: '.ai-first/context/REQUIREMENTS.md',
    label: 'Spec',
    description: 'Constraints, acceptance criteria, and non-negotiables.',
    status: 'live',
    lines: 63,
  },
  {
    name: 'ARCHITECTURE.md',
    path: '.ai-first/context/ARCHITECTURE.md',
    label: 'System',
    description: 'Modules, data flow, and the decisions behind the shape.',
    status: 'live',
    lines: 128,
  },
  {
    name: 'IN_PROGRESS.md',
    path: '.ai-first/context/IN_PROGRESS.md',
    label: 'Now',
    description: 'The task currently in flight, with open threads.',
    status: 'active',
    lines: 19,
  },
  {
    name: 'BACKLOG.md',
    path: '.ai-first/context/BACKLOG.md',
    label: 'Next',
    description: 'Prioritized work the agent can pull from with context.',
    status: 'queued',
    lines: 52,
  },
  {
    name: 'IDEAS.md',
    path: '.ai-first/context/IDEAS.md',
    label: 'Proposals',
    description: 'Agent suggestions parked here until the owner approves.',
    status: 'draft',
    lines: 27,
  },
  {
    name: 'CHANGELOG.md',
    path: '.ai-first/context/CHANGELOG.md',
    label: 'History',
    description: 'Decisions and changes, kept as durable memory.',
    status: 'live',
    lines: 210,
  },
]
